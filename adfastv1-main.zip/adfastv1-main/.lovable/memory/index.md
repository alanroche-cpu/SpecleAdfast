# Memory: index.md
Updated: now

Brand color: Burnt Orange (#C2410C primary, #9A3412 dark, #FFF7ED light, #EA580C accent)
Logos: src/assets/adfast-logo-white.png (adfast), src/assets/specle-logo.png (specle - used on login, Dashboard, Send Ad pages)
Nav labels: "Send Ad" (not Specs), "My Ad Deliveries" (not Tracking), "Colour Management" (not Colour)
Buttons: Green (#16A34A) for action/request buttons, solid black for secondary, no v="brand" on Save/Add
Bookings bulk bar: brand color background with Pending/Confirmed/Rejected buttons that update status
My Ad Deliveries bulk bar: brand color (not black)
Archive: archived items only show "Un-Archive" option
Send Ad nav always resets to publisher grid and clears search
Header search: shows dropdown with Publications/Publishers sections, clicking navigates to Publisher page
Dashboard stats order: Bookings, Require Attention, Waiting to be delivered, Completed This Month
Waiting to be delivered = deliveries without Sent or Received status
No booking count badge in nav (shown on Dashboard instead)
Preflight cost summary: "Total" (no Tier 2)
User icon: dropdown with My Account, Pricing, Logout (brand hover color)
Publication specs: full page (not popup)
SendAdForm: matches Create Delivery design with booking details, colour profile, notes, upload options
Re-Upload in My Ad Deliveries navigates to SendAdForm
